
import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';
import * as fs from 'fs/promises';
import path from 'path';

const CLIENT_SECRET_FILE = 'attached_assets/client_secret_816199065628-8bi3udmg52shqe2ac8anm8do285olh9m.a_1768238873456.json';
const TOKEN_PATH = path.join(process.cwd(), 'token.json');
const SCOPES = ['https://www.googleapis.com/auth/gmail.readonly'];

export async function getOAuthClient(): Promise<OAuth2Client> {
    const content = await fs.readFile(CLIENT_SECRET_FILE, 'utf-8');
    const credentials = JSON.parse(content);
    const { client_secret, client_id, redirect_uris } = credentials.installed;
    
    // Use Replit environment variable for redirect URI if available
    let redirectUri = redirect_uris[0];
    if (process.env.REPLIT_DEV_DOMAIN) {
        redirectUri = `https://${process.env.REPLIT_DEV_DOMAIN}/api/auth/google/callback`;
    }
    
    const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirectUri);

    try {
        const token = await fs.readFile(TOKEN_PATH, 'utf-8');
        oAuth2Client.setCredentials(JSON.parse(token));
    } catch (err) {
        // Token not found or invalid
    }
    return oAuth2Client;
}

export function getAuthUrl(oAuth2Client: OAuth2Client): string {
    return oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: SCOPES,
    });
}

export async function saveToken(oAuth2Client: OAuth2Client, code: string) {
    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);
    await fs.writeFile(TOKEN_PATH, JSON.stringify(tokens));
}

export async function getGmailService() {
    const auth = await getOAuthClient();
    return google.gmail({ version: 'v1', auth });
}
