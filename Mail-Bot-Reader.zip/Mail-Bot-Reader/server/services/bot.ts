
import { IStorage } from "../storage";
import TelegramBot from "node-telegram-bot-api";
import { getGmailService } from "./google_auth";
import { google } from "googleapis";
import imaps from "imap-simple";
import { simpleParser } from "mailparser";
import axios from "axios";
import * as cheerio from "cheerio";
import nodemailer from "nodemailer";

export class BotService {
  private storage: IStorage;
  private bot: TelegramBot | null = null;
  private checkInterval: NodeJS.Timeout | null = null;
  private isProcessing = false;

  constructor(storage: IStorage) {
    this.storage = storage;
  }

  async start() {
    console.log("Starting Bot Service...");
    const settings = await this.storage.getSettings();
    if (!settings || !settings.telegramToken) {
      console.log("Missing settings, cannot start bot.");
      return;
    }

    if (this.bot) {
        try {
             await this.bot.stopPolling();
        } catch (e) {
            // ignore
        }
    }

    try {
        // Enable polling to listen for commands
        this.bot = new TelegramBot(settings.telegramToken, { polling: true }); 

        // Add error handler to prevent crash on connection issues
        this.bot.on('polling_error', (error) => {
            console.error("Telegram polling error:", error);
            // Self-recovery logic: restart if it hangs
            if (error.message.includes('EFATAL')) {
                this.restart();
            }
        });
        
        this.bot.onText(/\/forward (.+)/, async (msg, match) => {
            if (!this.bot) return;
            const chatId = msg.chat.id.toString();
            const targetEmail = match?.[1];

            if (!targetEmail || !targetEmail.includes("@")) {
                await this.bot.sendMessage(chatId, "Please provide a valid email address. Usage: /forward your@email.com");
                return;
            }

            const settings = await this.storage.getSettings();
            if (!settings || !settings.gmailAppPassword) {
                await this.bot.sendMessage(chatId, "Gmail app password not configured in settings.");
                return;
            }

            await this.bot.sendMessage(chatId, `Waiting for the next Claude email to forward to ${targetEmail}...`);

            try {
                const config = {
                    imap: {
                        user: settings.gmailEmail,
                        password: settings.gmailAppPassword,
                        host: 'imap.gmail.com',
                        port: 993,
                        tls: true,
                        tlsOptions: { rejectUnauthorized: false },
                        keepalive: true
                    }
                };

                const connection = await imaps.connect(config);
                const box = await connection.openBox('INBOX');

                // Get the current highest UID to detect ONLY new messages
                let lastKnownUid = box.uidnext;
                console.log(`Starting wait for new emails. Last UID: ${lastKnownUid}`);

                let found = false;
                const timeout = 180000; // 3 minutes timeout
                const startTime = Date.now();

                // Use a more efficient IDLE-like approach by polling more frequently but with specific UID search
                while (Date.now() - startTime < timeout && !found) {
                    // Search for messages with UID greater than or equal to our starting point
                    const searchCriteria = [['UID', `${lastKnownUid}:*`]];
                    const fetchOptions = { bodies: ['HEADER', ''], struct: true };
                    const messages = await connection.search(searchCriteria, fetchOptions);
                    
                    if (messages.length > 0) {
                        // Sort to get the absolute latest
                        messages.sort((a: any, b: any) => b.attributes.uid - a.attributes.uid);
                        
                        for (const m of messages) {
                            if (m.attributes.uid < lastKnownUid) continue; 

                            const parts = m.parts || [];
                            const headerPart = parts.find((p: any) => p.which === 'HEADER');
                            const subject = headerPart?.body?.subject?.[0] || "";
                            const fromHeader = headerPart?.body?.from?.[0] || "";
                            
                            console.log(`New email detected: ${subject} from ${fromHeader} (UID: ${m.attributes.uid})`);

                            const lowerFrom = fromHeader.toLowerCase();
                            const lowerSubject = subject.toLowerCase();

                            if (lowerFrom.includes("anthropic") || 
                                lowerFrom.includes("claude") ||
                                lowerFrom.includes("openai") ||
                                lowerFrom.includes("chatgpt") ||
                                lowerSubject.includes("claude") ||
                                lowerSubject.includes("magic link") ||
                                lowerSubject.includes("openai") ||
                                lowerSubject.includes("chatgpt")) {
                                
                                const all = m.parts.find((part: any) => part.which === '');
                                if (all && all.body) {
                                    const mail = await simpleParser(all.body);
                                    const transporter = nodemailer.createTransport({
                                        host: 'smtp.gmail.com',
                                        port: 465,
                                        secure: true,
                                        auth: {
                                            user: settings.gmailEmail,
                                            pass: settings.gmailAppPassword
                                        }
                                    });

                                    await transporter.sendMail({
                                        from: `"${mail.from?.text || settings.gmailEmail}" <${settings.gmailEmail}>`,
                                        to: targetEmail,
                                        subject: mail.subject,
                                        text: mail.text,
                                        html: mail.html,
                                        headers: { 'X-Forwarded-By': 'Telegram Bot' }
                                    });

                                    await this.bot.sendMessage(chatId, "✅ New Claude email detected and forwarded!");
                                    found = true;
                                    break;
                                }
                            }
                            // Update lastKnownUid to avoid processing this message again
                            lastKnownUid = Math.max(lastKnownUid, m.attributes.uid + 1);
                        }
                    }

                    if (!found) {
                        // Polling faster (every 1 second) for "instant" feel
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }

                if (!found) {
                    await this.bot.sendMessage(chatId, "⏱ Timeout: No new Claude email detected within 3 minutes.");
                }

                await connection.end();
            } catch (error: any) {
                console.error("Forwarding failed:", error);
                await this.bot.sendMessage(chatId, `❌ Forwarding failed: ${error.message}`);
            }
        });

        this.bot.onText(/\/start/, async (msg) => {
            if (!this.bot) return;
            const chatId = msg.chat.id.toString();
            await this.storage.addSubscriber({
                chatId,
                username: msg.from?.username || msg.from?.first_name || "Unknown",
                isActive: true
            });
            await this.bot.sendMessage(chatId, "Welcome! You have been registered to receive verification codes. Use /code to check for the latest code manually.");
        });

        this.bot.onText(/\/stop/, async (msg) => {
            if (!this.bot) return;
            const chatId = msg.chat.id.toString();
            await this.storage.removeSubscriber(chatId);
            await this.bot.sendMessage(chatId, "You have been unsubscribed from notifications.");
        });

        this.bot.onText(/\/code/, async (msg) => {
            if (!this.bot) return;
            
            const chatId = msg.chat.id.toString();
            const subs = await this.storage.getSubscribers();
            if (!subs.find(s => s.chatId === chatId)) {
                await this.bot.sendMessage(chatId, "You are not registered. Use /start to register.");
                return;
            }

            await this.bot.sendMessage(chatId, "Searching for the latest code...");
            const found = await this.checkEmails();
            if (!found) {
                await this.bot.sendMessage(chatId, "No code found in the latest email.");
            } else {
                // Manually send result to the requester
                const latestCodes = await this.storage.getCodes();
                if (latestCodes.length > 0) {
                    const code = latestCodes[0];
                    const baseUrl = process.env.REPL_SLUG && process.env.REPL_OWNER 
                        ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
                        : "";
                    
                    const viewUrl = baseUrl ? `${baseUrl}/email/${code.id}` : "Settings required";

                    if (code.code === "VIEW_FULL_EMAIL") {
                         await this.bot?.sendMessage(chatId, `📧 **Full Email Received**\n\n[Click here to view full email in browser](${viewUrl})`, { 
                             parse_mode: 'Markdown',
                             disable_web_page_preview: true 
                         });
                    } else if (code.code.startsWith('http')) {
                         await this.bot?.sendMessage(chatId, `🔗 **Claude Login Link**\n\n[Click here to log in](${code.code})\n\n[Or view full email](${viewUrl})`, { 
                             parse_mode: 'Markdown',
                             disable_web_page_preview: true 
                         });
                    } else {
                         await this.bot?.sendMessage(chatId, `🔐 **Latest Code Found**\n\nCode: \`${code.code}\`\nSource: ${code.source}\n\n[View full email](${viewUrl})`, { 
                             parse_mode: 'Markdown',
                             disable_web_page_preview: true 
                         });
                    }
                }
            }
        });

    } catch (error) {
        console.error("Failed to initialize Telegram Bot:", error);
    }

    if (this.checkInterval) clearInterval(this.checkInterval);
    this.checkInterval = null;
  }

  async stop() {
    console.log("Stopping Bot Service...");
    if (this.checkInterval) clearInterval(this.checkInterval);
    this.checkInterval = null;
    
    if (this.bot) {
        try {
            await this.bot.stopPolling();
        } catch (e) {}
    }
    this.bot = null;
  }

  async restart() {
    await this.stop();
    await this.start();
  }

  async testConnection(): Promise<boolean> {
      const settings = await this.storage.getSettings();
      if (!settings) throw new Error("No settings found");

      if (settings.gmailAppPassword) {
          const config = {
              imap: {
                  user: settings.gmailEmail,
                  password: settings.gmailAppPassword,
                  host: 'imap.gmail.com',
                  port: 993,
                  tls: true,
                  tlsOptions: { rejectUnauthorized: false }, // Add this to bypass certificate error
                  authTimeout: 3000
              }
          };
          try {
              const connection = await imaps.connect(config);
              await connection.end();
              return true;
          } catch (error: any) {
              throw new Error("IMAP Connection Failed: " + error.message);
          }
      }

      try {
          const gmail = await getGmailService();
          await gmail.users.getProfile({ userId: 'me' });
          return true;
      } catch (error: any) {
          throw new Error("API Connection Failed: " + error.message);
      }
  }

  private async checkEmails(): Promise<boolean> {
    if (this.isProcessing) return false;
    this.isProcessing = true;

    try {
      const settings = await this.storage.getSettings();
      if (!settings) return false;

      // Prefer IMAP if password is provided
      if (settings.gmailAppPassword) {
          return await this.checkEmailsIMAP(settings);
      } else {
          return await this.checkEmailsAPI(settings);
      }
    } catch (error) {
      console.error("Error checking emails:", error);
      return false;
    } finally {
      this.isProcessing = false;
    }
  }

  private async checkEmailsIMAP(settings: any): Promise<boolean> {
    const config = {
        imap: {
            user: settings.gmailEmail,
            password: settings.gmailAppPassword,
            host: 'imap.gmail.com',
            port: 993,
            tls: true,
            tlsOptions: { rejectUnauthorized: false }, 
            authTimeout: 3000,
            connTimeout: 5000,
            keepalive: {
                interval: 10000,
                idleInterval: 300000,
                forceNoop: true
            }
        }
    };

    const connection = await imaps.connect(config);
    
    // Add error handler for the connection
    connection.on('error', (err: any) => {
        console.error("IMAP connection error:", err);
    });

    // Add close handler to ensure we know if it dropped
    connection.on('close', (hadError: boolean) => {
        console.log(`IMAP connection closed. Had error: ${hadError}`);
    });

    await connection.openBox('INBOX');

    const messages = await connection.search(['ALL'], {
        bodies: ['HEADER', ''],
        struct: true
    });
    if (messages.length === 0) {
        await connection.end();
        return false;
    }

    // Sort by sequence number descending to get the latest
    messages.sort((a: any, b: any) => b.attributes.uid - a.attributes.uid);
    const latestMessage = messages[0];

    const all = latestMessage.parts.find((part: any) => part.which === '');
    const id = latestMessage.attributes.uid;
    const subject = latestMessage.parts.find((part: any) => part.which === 'HEADER')?.body.subject?.[0] || "No Subject";
    
    const mail = await simpleParser(all.body);
    const content = mail.text || "";
    const html = mail.html || "";
    const from = mail.from?.text || "";

    // Store the full HTML content for later viewing if needed
    await this.storage.createCode({
        code: "VIEW_FULL_EMAIL",
        source: subject,
        content: html || content
    });

    // Handle Anthropic specific logic
    if (from.toLowerCase().includes("anthropic") || from.toLowerCase().includes("claude.ai")) {
        // More inclusive regex for Claude magic links
        // We match exactly what the user would see in a real browser
        const linkRegex = /https:\/\/claude\.ai\/magic-link#[a-f0-9-]+/gi;
        const links = html.match(linkRegex) || content.match(linkRegex);
        if (links && links.length > 0) {
            // Claude links are extremely sensitive to 'consumption'. 
            // We ensure we don't even log them to the console or touch them with axios.
            const authLink = links[0];
            await this.storage.createCode({
                code: authLink,
                source: `Anthropic: ${subject}`,
                content: "Sensitive login link (not shown in logs)"
            });
            await connection.end();
            return true;
        }
    }

    // Improved regex to avoid matching parts of URLs or long hashes
    const codeRegex = /\b\d{6}\b/g; 
    const matches = content.match(codeRegex);

    if (matches && matches.length > 0) {
        const code = matches[0];
        await this.storage.createCode({
            code,
            source: subject,
            content: content.substring(0, 200)
        });

        // Automatic mass notification disabled by user request
        await connection.end();
        return true;
    }

    await connection.end();
    return false;
  }

  private async checkEmailsAPI(settings: any): Promise<boolean> {
    const gmail = await getGmailService();
    const query = `newer_than:1d "verification" OR "code" OR "код" OR "подтверждение" ${settings?.filterSubject ? `subject:(${settings.filterSubject})` : ''}`;
    
    const res = await gmail.users.messages.list({
      userId: 'me',
      q: query,
      maxResults: 1
    });

    const messages = res.data.messages || [];
    if (messages.length === 0) return false;

    const msgInfo = messages[0];
    const msg = await gmail.users.messages.get({
      userId: 'me',
      id: msgInfo.id!,
      format: 'full'
    });

    const payload = msg.data.payload;
    const headers = payload?.headers || [];
    const subject = headers.find(h => h.name === 'Subject')?.value || "No Subject";
    
    let body = "";
    if (payload?.parts) {
        body = payload.parts[0].body?.data || "";
    } else {
        body = payload?.body?.data || "";
    }

    if (body) {
        const decodedBody = Buffer.from(body, 'base64').toString('utf-8');
        const codeRegex = /\b\d{6}\b|[A-Z0-9]{6,8}\b/g;
        const matches = decodedBody.match(codeRegex);

        if (matches && matches.length > 0) {
            const code = matches[0];
            await this.storage.createCode({
                code,
                source: subject,
                content: decodedBody.substring(0, 200)
            });

            // Automatic mass notification disabled by user request
            return true;
        }
    }
    return false;
  }
}
