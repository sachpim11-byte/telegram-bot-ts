
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { BotService } from "./services/bot";
import { getOAuthClient, saveToken, getAuthUrl } from "./services/google_auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const botService = new BotService(storage);

  app.get("/api/auth/google", async (req, res) => {
    try {
        const client = await getOAuthClient();
        const url = getAuthUrl(client);
        res.json({ url });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/auth/google/callback", async (req, res) => {
    const { code } = req.query;
    if (typeof code !== "string") {
      return res.status(400).send("No code provided");
    }
    try {
        const client = await getOAuthClient();
        await saveToken(client, code);
        res.redirect("/");
    } catch (error: any) {
        res.status(500).send("Auth failed: " + error.message);
    }
  });

  app.get(api.settings.get.path, async (req, res) => {
    const settings = await storage.getSettings();
    if (!settings) {
        return res.json({
            telegramToken: "",
            telegramChatId: "",
            gmailEmail: "",
            gmailAppPassword: "",
            filterSubject: "",
            isRunning: false
        });
    }
    res.json(settings);
  });

  app.patch(api.settings.update.path, async (req, res) => {
    const updated = await storage.updateSettings(req.body);
    if (updated.isRunning) {
        await botService.restart();
    }
    res.json(updated);
  });

  app.get(api.codes.list.path, async (req, res) => {
    const codes = await storage.getCodes();
    res.json(codes);
  });

  app.get("/email/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const codes = await storage.getCodes();
    const code = codes.find(c => c.id === id);
    if (!code || !code.content) {
      return res.status(404).send("Email not found");
    }
    res.setHeader('Content-Type', 'text/html');
    res.send(code.content);
  });

  app.post(api.bot.toggle.path, async (req, res) => {
    const { isRunning } = req.body;
    await storage.updateSettings({ isRunning });
    
    if (isRunning) {
        await botService.start();
    } else {
        await botService.stop();
    }
    
    res.json({ success: true, status: isRunning ? "running" : "stopped" });
  });

  app.post(api.bot.test.path, async (req, res) => {
      try {
          const success = await botService.testConnection();
          res.json({ success, message: success ? "Connection successful" : "Connection failed" });
      } catch (error: any) {
          res.status(400).json({ success: false, message: error.message });
      }
  });

  const settings = await storage.getSettings();
  if (settings?.isRunning) {
      botService.start();
  }

  return httpServer;
}
