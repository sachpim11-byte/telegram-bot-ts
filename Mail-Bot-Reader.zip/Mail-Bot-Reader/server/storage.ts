
import { db } from "./db";
import { settings, foundCodes, subscribers, type Settings, type InsertSettings, type InsertFoundCode, type FoundCode, type Subscriber, type InsertSubscriber } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
  createSettings(settings: InsertSettings): Promise<Settings>;
  
  getCodes(): Promise<FoundCode[]>;
  createCode(code: InsertFoundCode): Promise<FoundCode>;

  getSubscribers(): Promise<Subscriber[]>;
  addSubscriber(subscriber: InsertSubscriber): Promise<Subscriber>;
  removeSubscriber(chatId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getSettings(): Promise<Settings | undefined> {
    const [setting] = await db.select().from(settings).limit(1);
    return setting;
  }

  async createSettings(insertSettings: InsertSettings): Promise<Settings> {
    const [setting] = await db.insert(settings).values(insertSettings).returning();
    return setting;
  }

  async updateSettings(partialSettings: Partial<InsertSettings>): Promise<Settings> {
    const existing = await this.getSettings();
    if (!existing) {
       // Create default if not exists
       return this.createSettings({
           telegramToken: "",
           telegramChatId: "",
           gmailEmail: "",
           gmailAppPassword: "",
           filterSubject: "",
           isRunning: false,
           ...partialSettings
       } as InsertSettings);
    }
    
    const [updated] = await db
      .update(settings)
      .set(partialSettings)
      .where(eq(settings.id, existing.id))
      .returning();
    return updated;
  }

  async getCodes(): Promise<FoundCode[]> {
    return db.select().from(foundCodes).orderBy(desc(foundCodes.foundAt)).limit(50);
  }

  async createCode(code: InsertFoundCode): Promise<FoundCode> {
    const [newCode] = await db.insert(foundCodes).values(code).returning();
    return newCode;
  }

  async getSubscribers(): Promise<Subscriber[]> {
    return db.select().from(subscribers).where(eq(subscribers.isActive, true));
  }

  async addSubscriber(subscriber: InsertSubscriber): Promise<Subscriber> {
    const [existing] = await db.select().from(subscribers).where(eq(subscribers.chatId, subscriber.chatId));
    if (existing) {
      const [updated] = await db.update(subscribers).set({ isActive: true, username: subscriber.username }).where(eq(subscribers.chatId, subscriber.chatId)).returning();
      return updated;
    }
    const [newSub] = await db.insert(subscribers).values(subscriber).returning();
    return newSub;
  }

  async removeSubscriber(chatId: string): Promise<void> {
    await db.update(subscribers).set({ isActive: false }).where(eq(subscribers.chatId, chatId));
  }
}

export const storage = new DatabaseStorage();
