
import { z } from "zod";
import { insertSettingsSchema, settings, foundCodes, insertFoundCodeSchema } from "./schema";

export { insertSettingsSchema, insertFoundCodeSchema } from "./schema";
export type { InsertSettings, Settings, FoundCode, InsertFoundCode } from "./schema";

export const api = {
  settings: {
    get: {
      method: "GET",
      path: "/api/settings",
      responses: {
        200: insertSettingsSchema,
        404: z.object({ message: z.string() }),
      },
    },
    update: {
      method: "PATCH",
      path: "/api/settings",
      input: insertSettingsSchema.partial(),
      responses: {
        200: insertSettingsSchema,
      },
    },
  },
  codes: {
    list: {
      method: "GET",
      path: "/api/codes",
      responses: {
        200: z.array(z.custom<typeof foundCodes.$inferSelect>()),
      },
    },
  },
  bot: {
    toggle: {
      method: "POST",
      path: "/api/bot/toggle",
      input: z.object({ isRunning: z.boolean() }),
      responses: {
        200: z.object({ success: z.boolean(), status: z.string() }),
      },
    },
    test: {
        method: "POST",
        path: "/api/bot/test",
        responses: {
            200: z.object({ success: z.boolean(), message: z.string() })
        }
    }
  },
};
