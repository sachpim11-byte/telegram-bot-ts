import { useSettings } from "@/hooks/use-bot-settings";
import { SettingsForm } from "@/components/SettingsForm";
import { StatusCard } from "@/components/StatusCard";
import { RecentCodesList } from "@/components/RecentCodesList";
import { Loader2, Mail } from "lucide-react";

export default function Dashboard() {
  const { data: settings, isLoading } = useSettings();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-muted-foreground font-medium animate-pulse">Initializing Dashboard...</p>
        </div>
      </div>
    );
  }

  // Initial dummy settings if none exist
  const currentSettings = settings || {
    telegramToken: "",
    telegramChatId: "",
    gmailEmail: "",
    gmailAppPassword: "",
    filterSubject: "",
    isRunning: false,
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 lg:p-12">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <div className="bg-primary text-primary-foreground p-3 rounded-xl shadow-lg shadow-primary/25">
                <Mail className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-foreground font-display">
                Gmail Code Reader
              </h1>
              <p className="text-muted-foreground mt-1 text-lg">
                Automated Verification Code Forwarding
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground bg-card px-4 py-2 rounded-full border border-border shadow-sm">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
            System Online
          </div>
        </header>

        {/* Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
          
          {/* Left Column - Controls */}
          <div className="lg:col-span-4 space-y-6 lg:space-y-8 flex flex-col">
            <div className="flex-none">
                <StatusCard 
                isRunning={currentSettings.isRunning || false} 
                isLoading={isLoading} 
                />
            </div>
            <div className="flex-1">
                <SettingsForm settings={currentSettings} />
            </div>
          </div>

          {/* Right Column - Results */}
          <div className="lg:col-span-8 h-full min-h-[500px]">
            <RecentCodesList />
          </div>
        </div>

        {/* Footer */}
        <footer className="pt-8 text-center text-sm text-muted-foreground">
            <p>Gmail to Telegram Forwarder • Secure Local Processing</p>
        </footer>
      </div>
    </div>
  );
}
