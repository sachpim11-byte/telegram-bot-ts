import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type Settings, type InsertSettings, type FoundCode } from "@shared/routes";

// ============================================
// SETTINGS HOOKS
// ============================================

export function useSettings() {
  return useQuery({
    queryKey: [api.settings.get.path],
    queryFn: async () => {
      const res = await fetch(api.settings.get.path);
      if (res.status === 404) return null; // Handle case where no settings exist yet
      if (!res.ok) throw new Error("Failed to fetch settings");
      return api.settings.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateSettings() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (updates: Partial<InsertSettings>) => {
      const res = await fetch(api.settings.update.path, {
        method: api.settings.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      if (!res.ok) throw new Error("Failed to update settings");
      return api.settings.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.settings.get.path] });
    },
  });
}

// ============================================
// BOT CONTROL HOOKS
// ============================================

export function useToggleBot() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (isRunning: boolean) => {
      const res = await fetch(api.bot.toggle.path, {
        method: api.bot.toggle.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isRunning }),
      });
      if (!res.ok) throw new Error("Failed to toggle bot");
      return api.bot.toggle.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.settings.get.path] });
    },
  });
}

export function useTestBot() {
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.bot.test.path, {
        method: api.bot.test.method,
        headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) {
        const error = await res.json().catch(() => ({ message: "Test failed" }));
        throw new Error(error.message || "Test failed");
      }
      return api.bot.test.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// FOUND CODES HOOKS
// ============================================

export function useFoundCodes() {
  return useQuery({
    queryKey: [api.codes.list.path],
    queryFn: async () => {
      const res = await fetch(api.codes.list.path);
      if (!res.ok) throw new Error("Failed to fetch codes");
      return api.codes.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Poll every 5 seconds for new codes
  });
}
