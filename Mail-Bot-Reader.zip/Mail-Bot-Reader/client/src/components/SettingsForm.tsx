import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff, Save, Settings, Key, Mail, Lock, ExternalLink } from "lucide-react";
import { useSettings, useUpdateSettings } from "@/hooks/use-bot-settings";
import { insertSettingsSchema, type InsertSettings, type Settings as SettingsType } from "@shared/routes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { SiGoogle } from "react-icons/si";

export function SettingsForm({ settings }: { settings: SettingsType }) {
  const { toast } = useToast();
  const updateSettings = useUpdateSettings();
  const [showToken, setShowToken] = useState(false);
  const [showAppPassword, setShowAppPassword] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const handleGoogleAuth = async () => {
    setIsAuthenticating(true);
    try {
      const res = await fetch("/api/auth/google");
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error("Failed to get auth URL");
      }
    } catch (error: any) {
      toast({
        title: "Auth Error",
        description: error.message,
        variant: "destructive",
      });
      setIsAuthenticating(false);
    }
  };

  // Schema for validation - ensure we handle empty strings gracefully
  const formSchema = insertSettingsSchema.extend({
    telegramToken: z.string().min(1, "Required"),
    telegramChatId: z.string().min(1, "Required"),
    gmailEmail: z.string().email("Invalid email"),
    gmailAppPassword: z.string().min(1, "Required"),
  });

  const form = useForm<InsertSettings>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      telegramToken: settings.telegramToken || "",
      telegramChatId: settings.telegramChatId || "",
      gmailEmail: settings.gmailEmail || "",
      gmailAppPassword: settings.gmailAppPassword || "",
      filterSubject: settings.filterSubject || "",
    },
  });

  // Update form when settings load from API
  useEffect(() => {
    form.reset({
        telegramToken: settings.telegramToken || "",
        telegramChatId: settings.telegramChatId || "",
        gmailEmail: settings.gmailEmail || "",
        gmailAppPassword: settings.gmailAppPassword || "",
        filterSubject: settings.filterSubject || "",
    });
  }, [settings, form]);

  const onSubmit = (data: InsertSettings) => {
    updateSettings.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Settings Saved",
          description: "Your configuration has been updated successfully.",
        });
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message,
          variant: "destructive",
        });
      },
    });
  };

  return (
    <div className="bg-card rounded-2xl p-6 shadow-lg border border-border/50 h-full flex flex-col">
      <div className="mb-6">
        <h3 className="text-xl font-bold font-display flex items-center gap-2 mb-1">
          <Settings className="w-5 h-5 text-primary" />
          Configuration
        </h3>
        <p className="text-sm text-muted-foreground">Manage your credentials and filters</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 flex-1">
          <div className="space-y-4">
            {/* Telegram Section */}
            <div className="p-4 rounded-xl bg-background/50 border border-border/50 space-y-4">
                <h4 className="text-xs font-semibold uppercase text-muted-foreground flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span> Telegram
                </h4>
                
                <FormField
                control={form.control}
                name="telegramToken"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel className="text-xs">Bot Token</FormLabel>
                    <FormControl>
                        <div className="relative">
                        <Key className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                            {...field}
                            type={showToken ? "text" : "password"}
                            placeholder="123456789:ABCdef..."
                            className="input-field pl-9 pr-10"
                        />
                        <button
                            type="button"
                            onClick={() => setShowToken(!showToken)}
                            className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground transition-colors"
                        >
                            {showToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                        </div>
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />

                <FormField
                control={form.control}
                name="telegramChatId"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel className="text-xs">Chat ID</FormLabel>
                    <FormControl>
                        <div className="relative">
                        <span className="absolute left-3 top-2.5 text-muted-foreground font-mono text-xs">#</span>
                        <Input {...field} placeholder="123456789" className="input-field pl-8" />
                        </div>
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>

            {/* Gmail Section */}
            <div className="p-4 rounded-xl bg-background/50 border border-border/50 space-y-4">
                <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold uppercase text-muted-foreground flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span> Gmail
                    </h4>
                    <Button 
                        type="button" 
                        variant="outline" 
                        size="sm" 
                        className="h-7 text-[10px] gap-1.5 border-red-500/20 hover:bg-red-500/10 hover:text-red-500 transition-all"
                        onClick={handleGoogleAuth}
                        disabled={isAuthenticating}
                    >
                        <SiGoogle className="w-3 h-3" />
                        {isAuthenticating ? "Connecting..." : "Connect Google"}
                        <ExternalLink className="w-2.5 h-2.5" />
                    </Button>
                </div>
                
                <p className="text-[10px] text-muted-foreground leading-tight px-1">
                    Connect via Google (recommended) or use an App Password below.
                </p>
                
                <FormField
                control={form.control}
                name="gmailEmail"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel className="text-xs">Email Address</FormLabel>
                    <FormControl>
                        <div className="relative">
                        <Mail className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input {...field} placeholder="you@gmail.com" className="input-field pl-9" />
                        </div>
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />

                <FormField
                control={form.control}
                name="gmailAppPassword"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel className="text-xs">App Password</FormLabel>
                    <FormControl>
                        <div className="relative">
                        <Lock className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                            {...field}
                            type={showAppPassword ? "text" : "password"}
                            placeholder="xxxx xxxx xxxx xxxx"
                            className="input-field pl-9 pr-10"
                        />
                        <button
                            type="button"
                            onClick={() => setShowAppPassword(!showAppPassword)}
                            className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground transition-colors"
                        >
                            {showAppPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                        </div>
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />

                <FormField
                control={form.control}
                name="filterSubject"
                render={({ field }) => (
                    <FormItem>
                    <FormLabel className="text-xs">Subject Filter (Optional)</FormLabel>
                    <FormControl>
                        <Input {...field} placeholder="e.g. Verification Code" className="input-field" />
                    </FormControl>
                    <FormMessage />
                    </FormItem>
                )}
                />
            </div>
          </div>

          <div className="pt-4 mt-auto">
            <Button 
                type="submit" 
                className="w-full btn-primary bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all"
                disabled={updateSettings.isPending}
            >
              {updateSettings.isPending ? "Saving..." : "Save Configuration"}
              {!updateSettings.isPending && <Save className="ml-2 w-4 h-4" />}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
