import { useFoundCodes } from "@/hooks/use-bot-settings";
import { formatDistanceToNow } from "date-fns";
import { List, Copy, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export function RecentCodesList() {
  const { data: codes, isLoading } = useFoundCodes();
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      description: "Code copied to clipboard",
      duration: 2000,
    });
  };

  if (isLoading) {
    return (
      <div className="bg-card rounded-2xl p-6 shadow-lg border border-border/50 h-[400px] flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-12 w-12 bg-muted rounded-full mb-4"></div>
          <div className="h-4 w-32 bg-muted rounded mb-2"></div>
          <div className="h-3 w-24 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl p-6 shadow-lg border border-border/50 h-full flex flex-col">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold font-display flex items-center gap-2 mb-1">
            <List className="w-5 h-5 text-primary" />
            Recent Codes
          </h3>
          <p className="text-sm text-muted-foreground">Automatically detected verification codes</p>
        </div>
        <Badge variant="outline" className="px-3 py-1 bg-primary/5 text-primary border-primary/20">
            {codes?.length || 0} Found
        </Badge>
      </div>

      <ScrollArea className="flex-1 pr-4 -mr-4">
        {!codes || codes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-muted-foreground border-2 border-dashed border-border/50 rounded-xl bg-background/50">
            <Search className="w-10 h-10 mb-2 opacity-50" />
            <p className="font-medium">No codes found yet</p>
            <p className="text-xs opacity-70 mt-1 max-w-[200px] text-center">
              Ensure the bot is running and you have received new emails.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {codes.map((code) => (
              <div
                key={code.id}
                className="group p-4 rounded-xl border border-border/50 bg-background/50 hover:bg-background hover:border-primary/20 hover:shadow-md transition-all duration-300 relative overflow-hidden"
              >
                <div className="flex items-start justify-between mb-2 relative z-10">
                  <div className="font-mono text-2xl font-bold tracking-wider text-foreground">
                    {code.code}
                  </div>
                  <button
                    onClick={() => copyToClipboard(code.code)}
                    className="p-2 text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                    title="Copy code"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground relative z-10">
                  <div className="font-medium truncate max-w-[180px] text-foreground/80">
                    {code.source}
                  </div>
                  <div className="opacity-70">
                    {code.foundAt && formatDistanceToNow(new Date(code.foundAt), { addSuffix: true })}
                  </div>
                </div>

                <div className="absolute top-0 right-0 p-16 bg-gradient-to-br from-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
