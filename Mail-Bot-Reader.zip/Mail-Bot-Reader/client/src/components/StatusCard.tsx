import { Power, CheckCircle2, XCircle, RefreshCw } from "lucide-react";
import { useToggleBot, useTestBot } from "@/hooks/use-bot-settings";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface StatusCardProps {
  isRunning: boolean;
  isLoading: boolean;
}

export function StatusCard({ isRunning, isLoading }: StatusCardProps) {
  const { toast } = useToast();
  const toggleBot = useToggleBot();
  const testBot = useTestBot();

  const handleToggle = () => {
    toggleBot.mutate(!isRunning, {
      onSuccess: (data) => {
        toast({
          title: data.success ? "Success" : "Error",
          description: data.status,
          variant: data.success ? "default" : "destructive",
        });
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleTest = () => {
    testBot.mutate(undefined, {
      onSuccess: (data) => {
        toast({
          title: "Connection Verified",
          description: data.message,
        });
      },
      onError: (err) => {
        toast({
          title: "Connection Failed",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <div className="bg-card rounded-2xl p-6 shadow-lg border border-border/50 flex flex-col h-full justify-between overflow-hidden relative group">
      <div className="absolute top-0 right-0 p-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 group-hover:bg-primary/10 transition-colors duration-500 pointer-events-none" />
      
      <div>
        <h3 className="text-xl font-bold font-display flex items-center gap-2 mb-1">
          <Power className="w-5 h-5 text-primary" />
          System Status
        </h3>
        <p className="text-sm text-muted-foreground mb-6">Control the bot execution cycle</p>
      </div>

      <div className="space-y-6 relative z-10">
        <div className="flex items-center justify-between p-4 rounded-xl bg-background/50 border border-border">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-3 h-3 rounded-full shadow-[0_0_10px_currentColor]",
              isRunning ? "bg-green-500 text-green-500" : "bg-red-500 text-red-500"
            )} />
            <span className="font-medium">
              {isLoading ? "Loading..." : (isRunning ? "System Active" : "System Stopped")}
            </span>
          </div>
          
          <Button 
            onClick={handleToggle}
            disabled={toggleBot.isPending || isLoading}
            className={cn(
              "rounded-full px-6 transition-all duration-300 shadow-md",
              isRunning 
                ? "bg-destructive text-destructive-foreground hover:bg-destructive/90 hover:shadow-destructive/20" 
                : "bg-green-600 text-white hover:bg-green-700 hover:shadow-green-500/20"
            )}
          >
            {toggleBot.isPending ? (
              <RefreshCw className="w-4 h-4 animate-spin mr-2" />
            ) : isRunning ? (
              <Power className="w-4 h-4 mr-2" />
            ) : (
              <Power className="w-4 h-4 mr-2" />
            )}
            {isRunning ? "Stop Bot" : "Start Bot"}
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-lg bg-secondary/30 border border-border/50 flex flex-col items-center justify-center text-center">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Uptime</span>
                <span className="font-mono font-bold text-foreground">--:--</span>
            </div>
            <div className="p-3 rounded-lg bg-secondary/30 border border-border/50 flex flex-col items-center justify-center text-center">
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">Checks</span>
                <span className="font-mono font-bold text-foreground">--</span>
            </div>
        </div>

        <Button 
          variant="outline" 
          className="w-full border-primary/20 hover:bg-primary/5 hover:border-primary/40 text-primary"
          onClick={handleTest}
          disabled={testBot.isPending}
        >
            {testBot.isPending ? <RefreshCw className="w-4 h-4 animate-spin mr-2"/> : <CheckCircle2 className="w-4 h-4 mr-2" />}
            Test Credentials
        </Button>
      </div>
    </div>
  );
}
