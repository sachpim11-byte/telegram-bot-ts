## Packages
date-fns | Formatting dates for the recent codes list

## Notes
API endpoints are defined in shared/routes.ts
Settings include sensitive data (passwords), so fields should have visibility toggles
Polling will be used for the "Recent Codes" list to keep it fresh
